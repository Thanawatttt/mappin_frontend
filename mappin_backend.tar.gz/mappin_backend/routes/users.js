const router = require("express").Router();
const bcrypt = require("bcrypt");
const connect = require("../connect/connect");
const auth = require("../services/auth");
const { v4: uuidv4 } = require("uuid");

router.post("/register", async (req, res) => {

    console.log(req.body)


    if (req.body.password !== req.body.confirmPassword) {
        return res.status(400).send({
            status: false,
            error: true,
            message: "Your password not match"
        });
    }

    try {
        const salt = await bcrypt.genSalt(10);
        const hashedPassword = await bcrypt.hash(req.body.password, salt);

        const newUser = {
            uuid: uuidv4(),
            username: req.body.username,
            email: req.body.email,
            password: hashedPassword,
            createdAt: new Date(),
            createdBy: req.body.email,
            updatedAt: new Date(),
            updatedBy: req.body.email,
            statusItem: '001'
        }

        console.log(newUser);
        const user = await connect.insertMongoDB("user", newUser);
        if (user) res.status(200).send({ status: true, error: false, message: "User registered successfully" });
        else res.status(500).send({ status: false, error: true, message: "User registered failed" });
    } catch (err) {
        console.log(err)
        res.status(500).send(err);
    }
})

router.post("/login", async (req, res) => {
    try {
        const users = await connect.queryMongoDB("user", { email: req.body.email });

        // Check if user exists
        if (!users || users.length === 0) {
            return res.status(400).send({
                status: false,
                error: true,
                message: "User not found or wrong password"
            });
        }

        const user = users[0];

        // Verify password
        const validPassword = await bcrypt.compare(
            req.body.password,
            user.password
        );

        if (!validPassword) {
            return res.status(400).send({
                status: false,
                error: true,
                message: "User not found or wrong password"
            });
        }

        // Success - return token
        return res.status(200).send({
            status: true,
            error: false,
            token: auth.genTokenJWT(user)
        });
    } catch (err) {
        console.error("Login error:", err);
        return res.status(500).json({
            status: false,
            error: true,
            message: "Internal server error"
        });
    }
})

module.exports = router;