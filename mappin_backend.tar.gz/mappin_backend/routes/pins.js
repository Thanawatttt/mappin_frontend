const router = require("express").Router();
const auth = require("../services/auth");
const connect = require("../connect/connect"); // เพิ่มเพื่อให้เรียก insertMongoDB ได้
const { v4: uuidv4 } = require("uuid");

router.post("/", async (req, res) => {
    const token = await auth.decodeTokenJWT(req.headers['x-access-token']);

    if (token === 'Token missing.' || token === 'Token expired.') {
        return res.status(400).send({ status: false, error: true, message: token });
    }

    try {
        const newPin = {
            uuid: uuidv4(),
            uuidUser: token.uuid,
            title: req.body.title,
            desc: req.body.desc,
            rating: req.body.rating,
            lat: req.body.lat,
            long: req.body.long,
            createdAt: new Date(),
            createdBy: token.email,
            updatedAt: new Date(),
            updatedBy: token.email,
            statusItem: '001'
        };

        const pin = await connect.insertMongoDB("pin", newPin);

        if (pin) {
            res.status(200).send({
                status: true,
                error: false,
                message: "Created pin successfully"
            });
        } else {
            res.status(400).send({
                status: false,
                error: true,
                message: "Can't create pin"
            });
        }

    } catch (err) {
        console.log(err);
        res.status(500).json(err);
    }
});

router.get("/", async (req, res) => {
    try {
        const pins = await connect.queryMongoDB("pin", {});

        res.status(200).send({
            status: true,
            error: false,
            data: pins
        });
    } catch (err) {
        console.error("Error querying pins:", err);
        res.status(500).json({
            status: false,
            error: true,
            message: "Internal server error"
        });
    }
});

router.get("/all", async (req, res) => {

    try {
        const pin = await connect.queryMongoDB("pin");

        if (pin) res.status(200).send({ status: true, error: false, message: "Get pin successfully.", items: pin });
        else res.status(400).send({ status: false, error: true, message: "Can't not get" });

    } catch (err) {
        console.log(err);
        res.status(500).json(err);
    }
})

module.exports = router;