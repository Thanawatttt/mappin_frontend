const jwt = require("jsonwebtoken");
const jwtKey = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjEsInVzZXJuYW1lIjoidGluZyIsInJvbGUiOiJ1c2VyIiwiaWF0IjoxNzM2MzEzNjAwLCJleHAiOjE3MzYzMTcyMDB9.bP4mX6FzN2rA6M0pXJ5mJ6rGZKxvZ8YH7e3WwQyLQ0I";

const jwtTime = (60 * 60) * 1;

function genTokenJWT(data) {
    const source = {
        email: data.email,
        uuid: data.uuid,
    };

    const token = jwt.sign({ source }, jwtKey, {
        algorithm: "HS256",
        expiresIn: jwtTime,
    });

    return token;
}
module.exports.genTokenJWT = genTokenJWT;

function decodeTokenJWT(token) {
    const data = jwt.decode(token);

    if (!data || !data.source) {
        return "Token missing.";
    }

    if (data.exp && data.iat > data.exp) {
        return "Token expired.";
    }

    return data.source;
}
module.exports.decodeTokenJWT = decodeTokenJWT;