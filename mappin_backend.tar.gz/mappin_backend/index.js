const express = require("express"); // แก้จาก expess เป็น express
const app = express();
const cors = require("cors");
const bodyParser = require("body-parser");
const userRoute = require("./routes/users");
const pinRoute = require("./routes/pins");

// CORS configuration - allow requests from frontend
app.use(cors({
    origin: [
        'https://mappin-frontend.vercel.app',
        'http://localhost:5173',  // local development
        'http://localhost:4173'   // local preview
    ],
    credentials: true,
    methods: ['GET', 'POST', 'PUT', 'DELETE', 'OPTIONS'],
    allowedHeaders: ['Content-Type', 'x-access-token']
}));

app.use(bodyParser.json({ limit: '50mb' }));
app.use(bodyParser.urlencoded({ limit: '50mb', extended: true }));

app.get('/', (req, res) => {
    return res.send({
        status: true,
        error: false,
        message: "Welcome",
    })
})

app.use("/api/users", userRoute);
app.use("/api/pins", pinRoute);

const init = async () => {
    require("./connect/connect");
    app.listen(3001, () => {
        console.log('Server running on http://localhost:3001')
    });
}

init().catch(err => console.log(err.stack));