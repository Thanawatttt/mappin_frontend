const { MongoClient, ServerApiVersion } = require('mongodb');
const url = "mongodb://admin:0638935401z@me2.lunarmine.fun:27017/?authMechanism=PLAIN";

const client = new MongoClient(url, {
    serverApi: {
        version: ServerApiVersion.v1,
        strict: true,
        deprecationErrors: true
    }
});

async function run() {
    try {
        await client.connect();
        console.log("Connecting successfully.");
    } catch (error) {
        console.log("Error connecting to MongoDB:", error);
    }
}


async function insertMongoDB(collectionName, data) {
    try {
        await client.connect();
        const db = client.db("app");
        const collection = db.collection(collectionName);

        const insertResult = await collection.insertOne(data);
        console.log("Inserted document with ID:", insertResult.insertedId);
        return insertResult.insertedId;

    } catch (error) {
        console.error("Error inserting to MongoDB:", error);
        return false;
    }
}
module.exports.insertMongoDB = insertMongoDB;



async function queryMongoDB(collectionName, data) {
    try {
        await client.connect();
        const db = client.db("app");
        const collection = db.collection(collectionName);

        const items = await collection.find(data).toArray();
        console.log("Found", items.length, "documents");
        return items;

    } catch (error) {
        console.error("Error querying MongoDB:", error);
        return [];
    }
}
module.exports.queryMongoDB = queryMongoDB;


run().then(() => {
    console.log("Connected to MongoDB successfully");
})
    .catch((error) => {
        console.log("Error connecting to MongoDB:", error);
    });