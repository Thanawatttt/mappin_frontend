// Script สำหรับเพิ่มข้อมูล pins ตัวอย่างลงใน MongoDB
// รันด้วยคำสั่ง: mongosh "mongodb://admin:0638935401z@me2.lunarmine.fun:27017/?authMechanism=PLAIN" --file seed_pins.js

const db = db.getSiblingDB('app');

// ตัวอย่าง pin ที่ 1 - ร้านอาหาร
db.pin.insertOne({
    uuid: UUID().toString(),
    uuidUser: 'sample-user-uuid-1',
    title: 'ร้านอาหารอร่อย',
    desc: 'ร้านอาหารไทยรสชาติดี บรรยากาศสบาย ราคาไม่แพง',
    rating: 5,
    lat: 13.7563,
    long: 100.5018,
    createdAt: new Date(),
    createdBy: 'admin@example.com',
    updatedAt: new Date(),
    updatedBy: 'admin@example.com',
    statusItem: '001'
})

// ตัวอย่าง pin ที่ 2 - คาเฟ่
db.pin.insertOne({
    uuid: UUID().toString(),
    uuidUser: 'sample-user-uuid-2',
    title: 'Cozy Café',
    desc: 'คาเฟ่สไตล์มินิมอล กาแฟอร่อย ของหวานน่ารัก',
    rating: 4,
    lat: 13.7465,
    long: 100.5345,
    createdAt: new Date(),
    createdBy: 'user@example.com',
    updatedAt: new Date(),
    updatedBy: 'user@example.com',
    statusItem: '001'
})

// ตัวอย่าง pin ที่ 3 - สถานที่ท่องเที่ยว
db.pin.insertOne({
    uuid: UUID().toString(),
    uuidUser: 'sample-user-uuid-3',
    title: 'วัดพระแก้ว',
    desc: 'วัดที่สวยงามและมีประวัติศาสตร์ ควรไปเยี่ยมชม',
    rating: 5,
    lat: 13.7500,
    long: 100.4915,
    createdAt: new Date(),
    createdBy: 'tourist@example.com',
    updatedAt: new Date(),
    updatedBy: 'tourist@example.com',
    statusItem: '001'
})

// ตัวอย่าง pin ที่ 4 - ห้างสรรพสินค้า
db.pin.insertOne({
    uuid: UUID().toString(),
    uuidUser: 'sample-user-uuid-4',
    title: 'Siam Paragon',
    desc: 'ห้างสรรพสินค้าใหญ่ มีร้านค้ามากมาย',
    rating: 4,
    lat: 13.7467,
    long: 100.5349,
    createdAt: new Date(),
    createdBy: 'shopper@example.com',
    updatedAt: new Date(),
    updatedBy: 'shopper@example.com',
    statusItem: '001'
})

// ตัวอย่าง pin ที่ 5 - สวนสาธารณะ
db.pin.insertOne({
    uuid: UUID().toString(),
    uuidUser: 'sample-user-uuid-5',
    title: 'สวนลุมพินี',
    desc: 'สวนสาธารณะกลางกรุง เหมาะสำหรับออกกำลังกาย',
    rating: 4,
    lat: 13.7307,
    long: 100.5418,
    createdAt: new Date(),
    createdBy: 'runner@example.com',
    updatedAt: new Date(),
    updatedBy: 'runner@example.com',
    statusItem: '001'
})

print('✅ เพิ่มข้อมูล pins สำเร็จแล้ว!')
print('📊 จำนวน pins ทั้งหมด:', db.pin.countDocuments())
